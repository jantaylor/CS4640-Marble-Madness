
 _____ ______   ________  ________  ________  ___       _______      
|\   _ \  _   \|\   __  \|\   __  \|\   __  \|\  \     |\  ___ \     
\ \  \\\__\ \  \ \  \|\  \ \  \|\  \ \  \|\ /\ \  \    \ \   __/|    
 \ \  \\|__| \  \ \   __  \ \   _  _\ \   __  \ \  \    \ \  \_|/__  
  \ \  \    \ \  \ \  \ \  \ \  \\  \\ \  \|\  \ \  \____\ \  \_|\ \ 
   \ \__\    \ \__\ \__\ \__\ \__\\ _\\ \_______\ \_______\ \_______\
    \|__|     \|__|\|__|\|__|\|__|\|__|\|_______|\|_______|\|_______|
                                                                     
                                                                     
                                                                     

 _____ ______   ________  ________  ________   _______   ________   ________      
|\   _ \  _   \|\   __  \|\   ___ \|\   ___  \|\  ___ \ |\   ____\ |\   ____\     
\ \  \\\__\ \  \ \  \|\  \ \  \_|\ \ \  \\ \  \ \   __/|\ \  \___|_\ \  \___|_    
 \ \  \\|__| \  \ \   __  \ \  \ \\ \ \  \\ \  \ \  \_|/_\ \_____  \\ \_____  \   
  \ \  \    \ \  \ \  \ \  \ \  \_\\ \ \  \\ \  \ \  \_|\ \|____|\  \\|____|\  \  
   \ \__\    \ \__\ \__\ \__\ \_______\ \__\\ \__\ \_______\____\_\  \ ____\_\  \ 
    \|__|     \|__|\|__|\|__|\|_______|\|__| \|__|\|_______|\_________\\_________\
                                                           \|_________\|_________|
                                                                                  
													  
 __ __  ___  __    __      ______  ___       ____  _      ____ __ __ 
|  |  |/   \|  |__|  |    |      |/   \     |    \| |    /    |  |  |
|  |  |     |  |  |  |    |      |     |    |  o  ) |   |  o  |  |  |
|  _  |  O  |  |  |  |    |_|  |_|  O  |    |   _/| |___|     |  ~  |
|  |  |     |  `  '  |      |  | |     |    |  |  |     |  _  |___, |
|  |  |     |\      /       |  | |     |    |  |  |     |  |  |     |
|__|__|\___/  \_/\_/        |__|  \___/     |__|  |_____|__|__|____/ 
                                                                     

																	
Marble Madness CONTROLS

Player 1 Controls: Arrow Keys

Player 2 Controls : AWSD

How to Win!
Maneuver your player around the game board. Avoid enemies and falling off the edges. Get to the goal in time to win the level!
Try and beat the devs!

NOTES
All levels were designed and created with Blender by group members. Absolutely nothing was acquired from Unity's Asset store. Music was used with permission from Hal Canon and Brad Fuller. There is no credits page as these are supposed to be anonymous.

Features
- High Score Server for up to date scoring!
- Two player local play!
- 3 Levels and the easter egg "test" level!
- Animated models built in blender based off original game!

Missing
- When colliding with an enemy or falling off, it resets you to the start rather than from a "checkpoint" or save spot.
- Second player is unable to submit their score to the server.
- Not missing, but afte typing 3 characters in your name, it submits your score to the server.
- Unique audio track for level 2

